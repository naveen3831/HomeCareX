import { Router } from 'express';
import { authController } from './auth.controller';
import { authMiddleware } from '../../middleware/auth.middleware';
import { requireAdmin } from '../../middleware/role.middleware';
import { authRateLimit } from '../../middleware/rateLimit.middleware';

export const authRoutes = Router();

authRoutes.post('/login', authRateLimit, authController.login);
authRoutes.post('/register', authRateLimit, authController.register);
authRoutes.post('/refresh', authController.refresh);
authRoutes.post('/logout', authController.logout);
authRoutes.post('/forgot-password', authRateLimit, authController.forgotPassword);
// TEMP (local only): OTP handlers are missing from auth.controller.ts on develop
// authRoutes.post('/verify-otp', authRateLimit, authController.verifyOtp);
// authRoutes.post('/resend-otp', authRateLimit, authController.resendOtp);
authRoutes.post('/reset-password', authRateLimit, authController.resetPassword);
authRoutes.post('/verify-invite', authRateLimit, authController.verifyInvite);
authRoutes.post('/accept-invite', authRateLimit, authController.acceptInvite);
authRoutes.post('/revoke-user-sessions/:id', authMiddleware, requireAdmin, authController.revokeUserSessions);
authRoutes.get('/me', authMiddleware, authController.me);

export default authRoutes;