export interface AdminTypes {}
