export class PaymentsRepository {}
