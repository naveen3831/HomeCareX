export class CustomersRepository {}
