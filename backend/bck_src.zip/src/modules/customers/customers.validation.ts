export const customersValidation = {};
