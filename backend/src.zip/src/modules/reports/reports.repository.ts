export class ReportsRepository {}
