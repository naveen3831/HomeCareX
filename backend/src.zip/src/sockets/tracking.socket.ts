export const registerTrackingSocket = () => {};
