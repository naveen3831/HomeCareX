import React from "react";
import { Navigate, Outlet, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import type { UserRole } from "@/types/auth";
import CustomerAuthPending from "./CustomerAuthPending";

interface ProtectedRouteProps {
  allowedRoles?: UserRole[];
  /** Rendered when allowed. Defaults to <Outlet/> for nested routes. */
  children?: React.ReactNode;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ allowedRoles, children }) => {
  const { isAuthenticated, user, status } = useAuth();
  const location = useLocation();

  if (status === "loading") {
    // Customer pages show their own page skeleton instead of a full-screen spinner.
    if (/^\/customer(\/|$)/i.test(location.pathname)) {
      return <CustomerAuthPending pathname={location.pathname} />;
    }
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-50" role="status" aria-live="polite">
        <div className="text-center">
          <div className="mx-auto h-10 w-10 animate-spin rounded-full border-4 border-gray-200 border-t-[#4338ca]" />
          <p className="mt-4 text-sm text-gray-600">Checking your session...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    const isSecurityRoute = /\/security|\/logout/i.test(location.pathname);
    const returnUrl = isSecurityRoute ? "" : `?returnUrl=${encodeURIComponent(location.pathname + location.search)}`;
    const expired = status === "expired" ? (returnUrl ? "&expired=1" : "?expired=1") : "";
    return <Navigate to={`/login${returnUrl}${expired}`} replace />;
  }

  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return <Navigate to="/unauthorized" replace />;
  }

  return <>{children ?? <Outlet />}</>;
};

export default ProtectedRoute;