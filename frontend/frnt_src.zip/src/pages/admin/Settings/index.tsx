import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { useDragScroll } from '@/hooks/useDragScroll';
import {
  fetchSettings,
  saveSettings,
  SettingsApiError,
  type SettingsSection,
  type SettingValue,
} from '@/services/adminSettingsApi';
import { SettingField } from './SettingField';

const same = (a: unknown, b: unknown) => JSON.stringify(a) === JSON.stringify(b);

export const AdminSettingsPage: React.FC = () => {
  // Mouse drag-scroll for the tab strip (swipe already works on phones)
  const pageRef = useDragScroll<HTMLDivElement>('[role="tablist"]');
  const [sections, setSections] = useState<SettingsSection[]>([]);
  const [activeId, setActiveId] = useState('business');
  const [draft, setDraft] = useState<Record<string, SettingValue>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loadError, setLoadError] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState<{ ok: boolean; text: string } | null>(null);

  const apply = useCallback((next: SettingsSection[]) => {
    setSections(next);
    setDraft(Object.fromEntries(next.flatMap((s) => s.settings.map((x) => [x.key, x.value]))));
  }, []);

  useEffect(() => {
    fetchSettings()
      .then(apply)
      .catch((e: SettingsApiError) => setLoadError(e.message))
      .finally(() => setLoading(false));
  }, [apply]);

  const section = sections.find((s) => s.id === activeId) ?? sections[0];
  const dirtyKeys = useMemo(
    () => (section ? section.settings.filter((s) => !same(draft[s.key], s.value)).map((s) => s.key) : []),
    [section, draft],
  );

  const onSave = async () => {
    if (!section || dirtyKeys.length === 0) return;

    // Check numbers here first so a bad value (e.g. GST 118) shows its error immediately.
    const clientErrors: Record<string, string> = {};
    for (const s of section.settings) {
      if (!dirtyKeys.includes(s.key) || (s.type !== 'number' && s.type !== 'integer')) continue;
      const v = draft[s.key];
      if (typeof v !== 'number' || !Number.isFinite(v)) {
        clientErrors[s.key] = `${s.label} must be a number`;
      } else if (s.type === 'integer' && !Number.isInteger(v)) {
        clientErrors[s.key] = `${s.label} must be a whole number`;
      } else if ((s.min !== undefined && v < s.min) || (s.max !== undefined && v > s.max)) {
        clientErrors[s.key] =
          s.min !== undefined && s.max !== undefined
            ? `${s.label} must be between ${s.min} and ${s.max}${s.unit ? ` ${s.unit}` : ''}`
            : s.min !== undefined
              ? `${s.label} must be at least ${s.min}`
              : `${s.label} must be at most ${s.max}`;
      }
    }
    if (Object.keys(clientErrors).length > 0) {
      setErrors(clientErrors);
      setNotice({ ok: false, text: 'Please fix the highlighted field.' });
      return;
    }

    setSaving(true);
    setNotice(null);
    setErrors({});
    try {
      apply(await saveSettings(Object.fromEntries(dirtyKeys.map((k) => [k, draft[k]]))));
      setNotice({ ok: true, text: `${section.label} settings saved.` });
    } catch (e) {
      const err = e as SettingsApiError;
      setErrors(err.fields);
      setNotice({ ok: false, text: err.status === 403 ? 'You need the settings:manage permission.' : err.message });
    } finally {
      setSaving(false);
    }
  };

  const onCancel = () => {
    if (!section) return;
    setDraft((d) => ({ ...d, ...Object.fromEntries(section.settings.map((s) => [s.key, s.value])) }));
    setErrors({});
    setNotice(null);
  };

  return (
    <div ref={pageRef} className="admin-page-container min-w-0 max-w-full space-y-6 p-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
        <p className="mt-1 text-sm text-gray-500">Platform rules. Every change is recorded in the audit log.</p>
      </div>

      {loading && <p className="text-sm text-gray-500">Loading settings…</p>}
      {loadError && <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-700">{loadError}</p>}

      {section && (
        <div className="min-w-0 max-w-full overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm">
          <div
            role="tablist"
            className="flex w-full max-w-full gap-2 overflow-x-auto overscroll-x-contain border-b border-gray-200 px-4 py-3 [-webkit-overflow-scrolling:touch] [scrollbar-width:thin] [&::-webkit-scrollbar]:h-2 [&::-webkit-scrollbar-track]:bg-slate-100 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-slate-300"
          >
            {sections.map((s) => (
              <button
                key={s.id}
                role="tab"
                aria-selected={s.id === section.id}
                onClick={(e) => {
                  setActiveId(s.id);
                  setErrors({});
                  setNotice(null);
                  e.currentTarget.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
                }}
                className={`shrink-0 whitespace-nowrap rounded-full px-4 py-2 text-sm font-semibold transition-colors ${s.id === section.id ? 'bg-[#4338ca] text-white shadow-sm' : 'bg-gray-100 text-gray-600 hover:bg-gray-200 hover:text-gray-900'}`}
              >
                {s.label}
              </button>
            ))}
          </div>

          <div className="p-5">
            <p className="text-sm text-gray-500">{section.description}</p>
            {section.settings.map((s) => (
              <SettingField
                key={s.key}
                setting={s}
                value={draft[s.key] ?? s.value}
                error={errors[s.key]}
                onChange={(v) => {
                  setDraft((d) => ({ ...d, [s.key]: v }));
                  setErrors((e) => { const { [s.key]: _removed, ...rest } = e; return rest; });
                }}
              />
            ))}

            <div className="mt-4 flex items-center gap-3">
              <button
                type="button"
                onClick={onSave}
                disabled={saving || dirtyKeys.length === 0}
                className="rounded-xl bg-[#4338ca] px-4 py-2 text-sm font-semibold text-white hover:bg-[#3730a3] disabled:opacity-50"
              >
                {saving ? 'Saving…' : 'Save'}
              </button>
              <button
                type="button"
                onClick={onCancel}
                disabled={saving || dirtyKeys.length === 0}
                className="rounded-xl border border-gray-300 bg-white px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50 disabled:opacity-50"
              >
                Cancel
              </button>
              {notice && <span role="status" className={`text-sm ${notice.ok ? 'text-emerald-700' : 'text-red-600'}`}>{notice.text}</span>}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminSettingsPage;