import React from 'react';
import type { AdminSetting, SettingValue } from '@/services/adminSettingsApi';

interface Props {
  setting: AdminSetting;
  value: SettingValue;
  error?: string;
  onChange: (value: SettingValue) => void;
}

const inputCls = (error?: string) =>
  `w-full rounded-xl border px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-200 ${error ? 'border-red-400' : 'border-gray-300'}`;

/** One setting: label, description, the right input for its type, validation hint and error. */
export const SettingField: React.FC<Props> = ({ setting, value, error, onChange }) => {
  const id = `setting-${setting.key}`;
  const isNumber = setting.type === 'number' || setting.type === 'integer';
  const hint = isNumber && (setting.min !== undefined || setting.max !== undefined)
    ? `Allowed: ${setting.min ?? '…'} to ${setting.max ?? '…'}${setting.unit ? ` ${setting.unit}` : ''}`
    : setting.type === 'list' ? 'Comma-separated, 6-digit pincodes' : '';

  return (
    <div className="grid gap-2 border-b border-gray-100 py-4 last:border-0 md:grid-cols-[1fr_320px] md:gap-6">
      <div>
        <label htmlFor={id} className="text-sm font-semibold text-gray-900">{setting.label}</label>
        <p className="mt-0.5 text-xs text-gray-500">{setting.description}</p>
        {hint && <p className="mt-0.5 text-[11px] text-gray-400">{hint}</p>}
      </div>
      <div>
        {setting.type === 'boolean' ? (
          <button
            id={id}
            type="button"
            role="switch"
            aria-checked={value === true}
            onClick={() => onChange(value !== true)}
            className={`relative h-6 w-11 rounded-full transition-colors ${value === true ? 'bg-[#4338ca]' : 'bg-gray-300'}`}
          >
            <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all ${value === true ? 'left-[22px]' : 'left-0.5'}`} />
          </button>
        ) : isNumber ? (
          <div className="flex items-center gap-2">
            <input
              id={id}
              type="number"
              inputMode="decimal"
              className={inputCls(error)}
              value={typeof value === 'number' ? value : ''}
              min={setting.min}
              max={setting.max}
              step={setting.type === 'integer' ? 1 : 'any'}
              onChange={(e) => onChange(e.target.value === '' ? ('' as unknown as number) : Number(e.target.value))}
            />
            {setting.unit && <span className="text-xs text-gray-500">{setting.unit}</span>}
          </div>
        ) : setting.type === 'list' ? (
          <textarea
            id={id}
            rows={3}
            className={inputCls(error)}
            value={Array.isArray(value) ? value.join(', ') : ''}
            onChange={(e) => onChange(e.target.value.split(/[,\s]+/).filter(Boolean))}
          />
        ) : (
          <input
            id={id}
            type="text"
            className={inputCls(error)}
            value={typeof value === 'string' ? value : ''}
            maxLength={setting.maxLength}
            onChange={(e) => onChange(e.target.value)}
          />
        )}
        {error && <p role="alert" className="mt-1 text-xs text-red-600">{error}</p>}
      </div>
    </div>
  );
};

export default SettingField;
