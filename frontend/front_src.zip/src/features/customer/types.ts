import type { AddressView, CreateAddressRequest } from "@/types/address";

/**
 * Response contract for GET /api/v1/customer/dashboard.
 * Mirrors backend/src/modules/customer-dashboard/customer-dashboard.types.ts —
 * keep the two in sync when the backend DTO changes.
 */

export type BookingStatusDto =
  | "created"
  | "searching_for_partner"
  | "assigned"
  | "en_route"
  | "arrived"
  | "in_progress"
  | "completed"
  | "rated"
  | "cancelled_by_customer"
  | "cancelled_by_partner"
  | "no_show"
  | "disputed";

/** A saved address — same contract as /addresses (see types/address.ts). */
export type AddressDto = AddressView;

/** Body of POST /addresses. */
export type AddressInput = CreateAddressRequest;

/** Body of PUT /addresses/:id (any subset). */
export type AddressPatch = Partial<CreateAddressRequest>;

export interface DashboardBookingDto {
  id: string;
  serviceName: string;
  status: BookingStatusDto;
  /** ISO date-time. */
  scheduledAt: string;
  /** "Ramesh K." — null until a partner is assigned. */
  partnerName: string | null;
  /** 0–4: number of filled progress bars. */
  progressStep: number;
  address: { line1: string; area: string | null; city: string };
  total: number;
}

export interface DashboardCategoryDto {
  id: string;
  name: string;
  slug: string;
  icon: string | null;
  /** Cover photo the admin set in Categories ('' or missing: use the built-in photo). */
  imageUrl?: string;
  /** Icon image the admin uploaded ('' or missing: use the 3D icon). */
  iconUrl?: string;
  serviceCount: number;
}

export interface DashboardServiceDto {
  id: string;
  name: string;
  slug: string;
  categoryId: string;
  icon: string | null;
  price: number;
  durationMinutes: number;
  rating: number;
  ratingCount: number;
}

export interface CustomerDashboardDto {
  greeting: { name: string; firstName: string };
  /** True when the customer has never booked → show the welcome state. */
  isNewCustomer: boolean;
  defaultAddress: AddressDto | null;
  activeBookings: DashboardBookingDto[];
  upcomingBookings: DashboardBookingDto[];
  categories: DashboardCategoryDto[];
  recommendedServices: DashboardServiceDto[];
  unreadNotifications: number;
}
